export const stringData = {
    ALL_KATAS: `https://www.codewars.com/api/v1/users/catchaser/code-challenges/completed?page=`,
    SINGLE_KATA: `https://www.codewars.com/kata/`,
    KATA_BY_ID: `https://www.codewars.com/api/v1/code-challenges/`,
    BACKWARDS: `backwards`
};
