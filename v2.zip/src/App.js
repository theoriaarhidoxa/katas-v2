import './components/App.scss';
import React from "react";
import {BrowserRouter, HashRouter, Switch, Route} from 'react-router-dom';
import List from "./components/List";
import Item from "./components/Item";


function App() {
    return (
        <div className='wrapper'>
            <HashRouter>
                <Switch>
                    <Route path='/' exact component={List}/>
                    <Route path='/kata/:kataId' component={Item}/>
                </Switch>
            </HashRouter>
        </div>
    );
}

export default App;

/* router implementations:
https://www.freecodecamp.org/news/deploy-a-react-app-to-github-pages/
https://create-react-app.dev/docs/deployment/#github-pages-https-pagesgithubcom
*/
